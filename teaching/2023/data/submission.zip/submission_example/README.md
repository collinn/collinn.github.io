# Submission Details

## Notes

- Should include raw data, data cleaning script, and clean data (OK if you pulling from github or a website)
- Shiny app should be inside of an R Script file (not Rmarkdown) called app.R
- Minimal data cleaning should be in app.R -- it should all be isnide your data cleaning script

## Submission

Place all of the files described above:

    1. Raw data
    2. Clean data
    3. Data cleaning script
    4. Shiny app in app.R
    
inside a single folder and zip it. Your submission should look just like this zip file that you downloaded. Apps are due Friday by 11:59 pm
