
library(tidyr)
library(stringr)

dat <- read.csv("raw_data.csv")

# This is my data cleaning
dat <- pivot_longer(dat, 
                    cols = c(x, y), 
                    names_to = "Category", 
                    values_to = "Value")

write.csv(dat, "clean_data.csv")
