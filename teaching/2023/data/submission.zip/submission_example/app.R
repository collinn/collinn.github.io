library(shiny)

## This is my app with minimal processing
dat <- read.csv("clean_data.csv")

ui <- fluidPage(
  selectInput("var1", "x axis", choices = unique(dat$Category)),
  selectInput("var2", "Color", choices = unique(dat$Category)),
  plotOutput("myplot")
)

server <- function(input, output) {
  
  df <- reactive({
    subset(dat, Category == input$var1)
  })
  
  output$myplot <- renderPlot({
    ggplot(df(), aes_string("Value", "z", color = input$var2)) + geom_point()
  })
}

shinyApp(ui, server)